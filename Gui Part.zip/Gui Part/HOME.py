import tkinter as tk
#from tkinter import ttk, LEFT, END
from PIL import Image , ImageTk 

root = tk.Tk()
root.configure(background="seashell2")


w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("%dx%d+0+0" % (w, h))
root.title("Bird Species Identification System")


#For background Image
image2 =Image.open('bg.jpg')
image2 =image2.resize((w,h), Image.ANTIALIAS)

background_image=ImageTk.PhotoImage(image2)

background_label = tk.Label(root, image=background_image)

background_label.image = background_image

background_label.place(x=0, y=0)

lbl = tk.Label(root, text="Bird Species Identification System", font=('times', 35,' bold '), bd=20, height=1, width=32,bg="black",fg="white")
lbl.place(x=300, y=10)


frame_alpr = tk.LabelFrame(root, text=" --MENU-- ", width=420, height=450, bd=20, font=('times', 14, ' bold '),bg="gray")
frame_alpr.grid(row=0, column=0, sticky='nw')
frame_alpr.place(x=550, y=270)


    
    
def window():
    root.destroy()




button1 = tk.Button(frame_alpr, text=" Upload Audio File ", width=15, height=1,bd=10, font=('times', 15, ' bold '),bg="maroon",fg="white")
button1.place(x=100, y=100)


button4 = tk.Button(frame_alpr, text="Detect voice", width=15, height=1, bd=10, bg="maroon",fg="white", font=('times', 15, ' bold '))
button4.place(x=100, y=190)



exit = tk.Button(frame_alpr, text="Back", command=window, width=15, height=1,bd=10, font=('times', 15, ' bold '),bg="maroon",fg="white")
exit.place(x=100, y=280)



root.mainloop()